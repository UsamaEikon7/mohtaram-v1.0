This folder is created by Zeeshan Khuwaja

This would be used only for modals integerated through out the webssite

Each modals should have unique id and id should be the same as the filename
