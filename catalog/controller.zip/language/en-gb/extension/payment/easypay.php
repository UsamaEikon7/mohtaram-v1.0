<?php
$_['text_title'] = 'Easypay Payment Method';
$_['button_confirm'] = 'Confirm Order';
?>