<?php
// Text
$_['text_subject']				= '%s - Post Comment';
$_['text_waiting']				= 'You have a new post comment waiting.';
$_['text_blog_post']			= 'Post: %s';
$_['text_commenter']			= 'Commenter: %s';
$_['text_comment']				= 'Comment Text:';