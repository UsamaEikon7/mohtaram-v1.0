<?php
// Heading
$_['heading_title'] 	= 'Categories';

$_['heading_search'] 	= 'Search';
$_['heading_category'] 	= 'Category';
$_['heading_archive'] 	= 'Archive';
$_['heading_post'] 		= 'Recent Post';
$_['heading_comment'] 	= 'Recent Comment';
$_['heading_tag']       = 'Tags:';

// Text
$_['text_search'] 		= 'Search Blog Post';
